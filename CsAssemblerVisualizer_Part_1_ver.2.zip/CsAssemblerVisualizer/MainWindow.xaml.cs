﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.IO;
using System.Security.Policy;
using System.Diagnostics;
using System.Text;

namespace GraphicModes
{

    public static class SomeAssemblerFunctions
    {

        //[DllImport("kernel32", SetLastError = true, CharSet = CharSet.Ansi)]
        //static extern IntPtr LoadLibrary([MarshalAs(UnmanagedType.LPStr)]string lpFileName);
        

        [DllImport("MyClassCppAssembler.dll"
        //, EntryPoint = "??4MyClass@@QAEAAV0@$$QAV0@@Z"
            , CallingConvention = CallingConvention.Cdecl
            )]
        static public extern IntPtr Create();

        [DllImport("MyClassCppAssembler.dll"
          //   , EntryPoint = "??4MyClass@@QAEAAV0@ABV0@@Z"
            , CallingConvention = CallingConvention.Cdecl
            )]
        static public extern void Dispose(IntPtr pMyClass);

        [DllImport("MyClassCppAssembler.dll"
          //   , EntryPoint = "?SetFoo_1@MyClass@@QAEXXZ"
            , CallingConvention = CallingConvention.Cdecl
            )]
        static public extern void SetFoo_1(IntPtr pMyClass);

        [DllImport("MyClassCppAssembler.dll"
          //    , EntryPoint = "?GetEAX@MyClass@@QAEHXZ"
            , CallingConvention = CallingConvention.Cdecl
            )]
        static public extern int GetEAX(IntPtr pGraphicsObject);
    }



    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            txbResult_ASM_Foo_1.Text = "Waiting to press 'Start'";
        }

        void OnClickStart(object sender, RoutedEventArgs e)
        {
        
            IntPtr pMyClass = SomeAssemblerFunctions.Create();

         
            Int32 a = 0;
            Int64 b = 0;
            long c = 0;
            long rslt = 0;

            try
            {
                SomeAssemblerFunctions.SetFoo_1(pMyClass);

                if (Environment.Is64BitOperatingSystem)
                {
                    //"SysWOW64"
                    b = SomeAssemblerFunctions.GetEAX(pMyClass);
                    txbResult_ASM_Foo_1.Text = (b == 1) ? (1).ToString() : (0).ToString();
                }
                else
                {
                    //"system32"
                    a = SomeAssemblerFunctions.GetEAX(pMyClass);
                    txbResult_ASM_Foo_1.Text = (a == 1) ? (0).ToString() : (0).ToString();
                }

                txbResult_ASM_Foo_1.Text = (rslt == 1) ? (1).ToString() : (0).ToString();
            }
            catch (Exception)
            {
                // MessageBox.Show(ex.Message);
                //  MessageBox.Show(ex.GetType().ToString());
                txbResult_ASM_Foo_1.Text = "Error";
            }
        }
    }  
}
